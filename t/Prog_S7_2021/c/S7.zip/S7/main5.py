from mylib.submod import f,h

f()
print(h(50))
