import mylib
import mylib.submod

mylib.f()
print(mylib.g(50))
mylib.submod.f()
print(mylib.submod.h(50))
