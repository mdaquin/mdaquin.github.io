

with open("file3.txt") as f:
    line1 = f.readline()
    line2 = f.readline()

print(f.closed)
print("line 1:", line1)
print("line 2:", line2)
