from module import C

i = C(5)
print(i.a)
