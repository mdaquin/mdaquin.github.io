

f = open("file3.txt", encoding="utf-8")
for i,l in enumerate(f.readlines()):
    print(i,":",l)
f.close()


f = open("file3.txt", encoding="latin1")
for i,l in enumerate(f.readlines()):
    print(i,":",l)
f.close()

f = open("file3.txt", encoding="ascii")
for i,l in enumerate(f.readlines()):
    print(i,":",l)
f.close()


