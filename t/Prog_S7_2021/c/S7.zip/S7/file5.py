
f= open("file4.txt", "a+")
f.write("BOB")
f.seek(0)
print(f.read())
f.seek(0)
f.write("ALICE")
print(f.read())
f.close()
