from mylib import submod

submod.f()
print(submod.h(50))
