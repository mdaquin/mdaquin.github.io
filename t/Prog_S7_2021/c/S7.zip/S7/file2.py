
f = open("file2.txt", "w")
f.write("I'm writing in a file!\n")
f.write("Doing it again!\n")
f.write("Getting a bit boring now.\n")
f.write("...")
f.write("done now...")
f.close()
