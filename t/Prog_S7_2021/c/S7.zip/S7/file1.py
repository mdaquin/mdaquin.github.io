

f = open("file1.txt")
lines = f.readlines()
print(lines)
for i,l in enumerate(lines):
    print(f"Line {i}: {l}")
f.close()
