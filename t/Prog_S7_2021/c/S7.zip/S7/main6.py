from mylib.submod import f,h
from mylib import f,g

f()
print(h(50))
