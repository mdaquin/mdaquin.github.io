
a = 12
def f(): print("f in mylib")
def g(x): return x+a
