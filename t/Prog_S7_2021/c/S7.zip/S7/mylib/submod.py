
a = 23
def f(): print("f in submod")
def h(x): return x-a
