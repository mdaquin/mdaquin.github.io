
__doc__ = """This is probably the best module
you have ever seen."""

a = 12

def b(x): return x+a

class C:
    def __init__(self, x):
        self.a = b(x)
