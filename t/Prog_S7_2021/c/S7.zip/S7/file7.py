
data = []
with open("mk_bodies.csv") as f:
    line = f.readline()
    while line:
       data.append(line.strip().split(","))
       line = f.readline()

print(data)
