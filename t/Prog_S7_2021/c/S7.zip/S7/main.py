import module as mymod

print(dir(mymod))
print(mymod.__doc__)

print(mymod.a)
print(mymod.b(3))
i = mymod.C(5)
print(i.a)
